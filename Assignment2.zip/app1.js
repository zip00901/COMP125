<script>

var Pizza 1 = "Pepperoni pizza";
var Pizza 2 = "Hawaiian pizza ";
var Pizza 3 = "California-style pizza ";
var Pizza 4 = "Neapolitan pizza";
var Pizza 1 = $13;
var Pizza 2 = $15;
var Pizza 3 = $17;
var Pizza 4 = $20;
</script>
<table>
<thead>
<tr>
<th>Pizza Menu</th>
<th>Price</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<script>
document.write(Pizza 1);
</script>
</td>
<td>
<script>
document.write(Pizza 1);
</script>
</td>
</tr>
<tr>
<td>
<script>
document.write(Pizza 2);
</script>
</td>
<td>
<script>
document.write(Pizza 2);
</script>
</td>
</tr>
<tr>
<td>
<script>
document.write(Pizza 3);
</script>
</td>
<td>
<script>
document.write(Pizza 3);
</script>
</td>
</tr>
<tr>
<td>
<script>
document.write(Pizza 4);
</script>
</td>
<td>
<script>
document.write(Pizza 4);
</script>
</td>
</tr>
</tbody>
</table>
</article>

