var daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday",
   "Thursday", "Friday", "Saturday"];

var ordered = ["Order: Pepperoni pizza Name:James Option: Take-away", "Order: Hawaiian pizza Name:Elln Option: Take-away", "Order: California-style pizza Name:Jessica Option: Take-away",
    "Order: Neapolitan pizza Name:Olivia Option: Take-away", "Order: Pepperoni pizza Name:James Option: Take-away", "Order: Neapolitan pizza Name:Leo Option: Take-away", "Order: Pepperoni pizza Name:James Option: Take-away",
    "Order: Pepperoni pizza Name:Shopia Option: Take-away", "Order: Neapolitan pizza Name:James Option: Take-away", "Order: Pepperoni pizza Name:Logan Option: Take-away",
    "Order: Hawaiian pizza Name:Mia Option: Take-away", "(off)", "Order: Neapolitan pizza Name:Max Option: Take-away", "Order: Hawaiian pizza Name:Grace Option: Take-away",
    "Order: Hawaiian pizza Name:Ava Option: Take-away", "(off)", "Order: Neapolitan pizza Name:Harry Option: Take-away", "Order: Hawaiian pizza Name:Jacob Option: Take-away",
    "(off)", "Order: Neapolitan pizza Name:Emily Option: Take-away", "California-style pizza Name:Amelia Option: Take-away",
    "Order: California-style pizza Name:James Option: Take-away", "(off)", "Order: California-style pizza Name:James Option: Take-away", "(off)",
    "Order: Neapolitan pizza Name:Lucas Option: Take-away", "Order: California-style pizza Name:Finley Option: Take-away", "Order: Neapolitan pizza Name:Teddy Option: Take-away", "Order: California-style pizza Name:Isaac Option: Take-away",
    "(off)", "(off)"];

var name =
["James","Elln","Jessica","Shopia","Olivia",
"Amelia","Isla","Emily","Ava","Lily",
"Jack","Harry","Grace","Isbella","Mia",
"","Jacob","Alfie","Oscar","Roony",
"Leo","Logan","","Henry","Max",
"Isaac","Teddy","Finley","Lucas","",
""];

var option  =
   ["Take-away ", "Take-away ", "Eat-in", "Take-away ", "Eat-in", "Take-away ", "Take-away ",
    "Take-away ", "Eat-in", "Take-away ", "Take-away ", "Take-away ", "Take-away ", "Take-away ",
    "Eat-in", "", "Take-away ", "Take-away ", "Eat-in", "Eat-in", "Take-away ",
    "Take-away ", "", "Take-away ", "Eat-in", "Take-away ", "Take-away ", "Take-away ",
    "Eat-in", "", ""];


function addColumnHeaders() {
   var i = 0;
   while (i < 7) {
      document.getElementsByTagName("th")[i].innerHTML = daysOfWeek[i];
      i++;
   }
}


function addCalendarDates() {
   var i = 1;
   var paragraphs = "";
   do {
      var tableCell = document.getElementById("08-" + i);
      paragraphs = tableCell.getElementsByTagName("p");
      paragraphs[0].innerHTML = i;
      i++;
   } while (i <= 31);
}


function addOrderInfo() {
   var paragraphs = "";
   for (var i = 0; i < 31; i++) {
      var date = i+1;
      var tableCell = document.getElementById("08-" + date);
      paragraphs = tableCell.getElementsByTagName("p");

if (name[i] === "name") {
         paragraphs[1].innerHTML = ": ";
      }
      if (name[i] === "name") {
         paragraphs[1].innerHTML = ": ";
      }
      else {
         if (name[i] === "name") {
            paragraphs[1].innerHTML = ": ";
         }
      }


      switch (option[i]) {
		  case "ordered ":
		  paragraphs[1].innerHTML="order : ";
         case "name":
            paragraphs[1].innerHTML = "name : ";
            break;
         case "option":
            paragraphs[1].innerHTML = "Option : ";
            break;
      }
paragraphs[1].innerHTML = ordered[i];




   }
}


function setUpPage() {
   addColumnHeaders();
   addCalendarDates();
   addOrderInfo();
}


if (window.addEventListener) {
   window.addEventListener("load", setUpPage, false);
} else if (window.attachEvent) {
   window.attachEvent("onload", setUpPage);
}
