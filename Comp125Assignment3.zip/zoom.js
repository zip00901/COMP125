
function view() {
    imgsrc = "IMG_01.jpg";


    viewwin = window.open(imgsrc, 'viewwin', 'width=600,height=300');
}

function closeWin() {
    Window.close();
}
